from django.db import models
from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType
from django.db.models import UniqueConstraint
from apps.utils.base_models import BaseModel
from apps.companies.models import Company
from django.utils.translation import gettext_lazy as _

# Create your models here.
class CompanyDirector(BaseModel):
    class DirectorGender(models.TextChoices):
        MALE = "male", "Male"
        FEMALE = "female", "Female"
    
    class Positions(models.TextChoices):
        DIRECTOR = "director", "Director"
        SECRETARY = "secretary", "Secretary"
        CHAIRMAN = "chairman", "Chairman"
        OTHER = "other", "Other"

    company = models.ForeignKey(
        Company,
        on_delete=models.CASCADE,
        related_name='directors'
    )
    individual = models.ForeignKey(
        "individuals.Individuals",
        on_delete=models.CASCADE,
        related_name='directorships',
        blank=True,
        null=True
    )
    position = models.CharField(
        max_length=20,
        choices=Positions.choices,
        default=Positions.DIRECTOR,
        help_text=_("Director position in the company")
    )
    date_of_appointment = models.DateField(
        blank=True, 
        null=True,
        help_text=_("Date of appointment as secretary")
    )
    
    class Meta:
        ordering = ["-created_at"]
        db_table = 'company_directors'
        verbose_name = "Company Director"
        verbose_name_plural = "Company Directors"
        unique_together = ("company", "individual", "position")

    def __str__(self):
        name = self.individual.full_name if self.individual else "Unknown"
        return f"{name} | ({self.company})"


class CompanySecretary(BaseModel):
    company = models.ForeignKey(
        Company,
        on_delete=models.CASCADE,
        blank=True,
        null=True,
        related_name='secretary_appointments'
    )
    secretary = models.ForeignKey(
        Company,
        on_delete=models.CASCADE,
        blank=True,
        null=True,
        related_name='secretary_for'
    )    
    date_of_appointment = models.DateField(
        blank=True, 
        null=True,
        help_text=_("Date of appointment as secretary")
    )

    class Meta:
        ordering = ["-created_at"]
        db_table = 'company_secretaries'
        verbose_name = "Company Secretary"
        verbose_name_plural = "Company Secretaries"        