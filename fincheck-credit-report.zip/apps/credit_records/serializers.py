from rest_framework import serializers
from apps.utils.mini_serializers import MiniIndividualDebtorSerializers, MiniCompanyDebtorSerializers
from .models import Claims, Absconders, CourtJudgement, InsolvencyRecord, PublicInformation
from apps.individuals.models import Individuals
from apps.utils.base_serialisers import NullableDateField

def _get_debtor_data(debtor):
    if not debtor:
        return None
    if isinstance(debtor, Individuals):
        return MiniIndividualDebtorSerializers(debtor).data
    return MiniCompanyDebtorSerializers(debtor).data

#READ SERIALIZERS 
class ClaimsSerializer(serializers.ModelSerializer):
    debtor = serializers.SerializerMethodField()
    class Meta:
        model = Claims
        fields = [
            "id",
            "debtor",
            "creditor_name",
            "currency",
            "amount",
            "account_number",
            "overdue_balance",            
            "claim_date",
            "status",
        ]

    def get_debtor(self, obj):
        return _get_debtor_data(obj.debtor)

class AbscondersSerializer(serializers.ModelSerializer): 
    debtor =  serializers.SerializerMethodField()
    class Meta:
        model = Absconders
        fields = [
            "id",
            "debtor",
            "creditor_name",
            "currency",
            "amount",
            "account_number",
            "overdue_balance",
            "start_date",
            "status",
        ]
    
    def get_debtor(self, obj):
        return _get_debtor_data(obj.debtor)
    
class CourtJudgementSerializer(serializers.ModelSerializer):
    class Meta:
        model = CourtJudgement
        fields = [
            "id",
            "court_name",
            "case_number",
            "judgement_date",
            "currency",
            "amount",
            "status",
            "plaintf_name"
        ]

class InsolvencyRecordSerializer(serializers.ModelSerializer):
    class Meta:
        model = InsolvencyRecord
        fields = [
            "id",
            "start_date",
            "end_date",
            "court_reference",
            "insolvency_type",
        ]
    

class PublicInformationSerializer(serializers.ModelSerializer):
    class Meta:
        model = PublicInformation
        fields = [
            "id",
            'record_date',
            "summary",
            "link",
        ]

# WRITE SERIALIZERS

class ClaimsWriteSerializer(serializers.ModelSerializer):
    claim_date = NullableDateField(required=False, allow_null=True)
    class Meta:
        model = Claims
        fields = [
            "subject_content_type",
            "subject_object_id",
            "debtor_content_type",
            "debtor_object_id",
            "creditor_name",
            "currency",
            "account_number",
            "overdue_balance",            
            "amount",
            "claim_date",
            "status",
        ]
class AbscondersWriteSerializer(serializers.ModelSerializer):
    start_date = NullableDateField(required=False, allow_null=True)
    class Meta:
        model = Absconders
        fields = [
            "subject_content_type",
            "subject_object_id",
            "debtor_content_type",
            "debtor_object_id",
            "creditor_name",
            "currency",
            "account_number",
            "overdue_balance",                       
            "amount",
            "start_date",
            "status",
        ]


class CourtJudgementWriteSerializer(serializers.ModelSerializer):
    judgement_date = NullableDateField(required=False, allow_null=True)

    class Meta:
        model = CourtJudgement
        fields = [
            "subject_content_type",
            "subject_object_id",
            "court_name",
            "case_number",
            "judgement_date",
            "currency",
            "status",
            "plaintf_name",
            "amount",
        ]


class InsolvencyRecordWriteSerializer(serializers.ModelSerializer):
    start_date = NullableDateField(required=False, allow_null=True)
    end_date = NullableDateField(required=False, allow_null=True)

    class Meta:
        model = InsolvencyRecord
        fields = [
            "subject_content_type",
            "subject_object_id",
            "insolvency_type",
            "start_date",
            "end_date",
            "court_reference"
        ]
class PublicInformationWriteSerializer(serializers.ModelSerializer):
    record_date = NullableDateField(required=False, allow_null=True)
    class Meta:
        model = PublicInformation
        fields = [
            "subject_content_type",
            "subject_object_id",
            'record_date',
            "summary",
            "link",
        ]