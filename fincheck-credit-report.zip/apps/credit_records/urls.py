from django.urls import path, include
from rest_framework.routers import SimpleRouter
from .views import CreditRecordsViewSet

router = SimpleRouter()
router.register(r"credit-records", CreditRecordsViewSet, basename="credit-records")

urlpatterns = [
    path("", include(router.urls)),
]
