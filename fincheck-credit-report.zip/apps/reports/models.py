
import secrets
from django.db import models
from apps.utils.base_models import BaseModelWithSubject, BaseModel
from django.contrib.contenttypes.models import ContentType
from django.contrib.contenttypes.fields import GenericForeignKey
from django.utils.translation import gettext_lazy as _
from django.db.models import UniqueConstraint
from django.db import transaction
from django.utils import timezone
from datetime import timedelta
from django.db.models import OrderBy, F
from django.db.models.functions import Coalesce
from django.core.serializers.json import DjangoJSONEncoder

def report_pdf_path(instance, filename):
    from django.conf import settings
    now = timezone.now()
    token = secrets.token_hex(5)
    ref = instance.enquiry_reference or "unref"
    return f"{ 'l' if not settings.DEBUG else 't' }/reports/{now.strftime('%Y')}/{now.strftime('%b')}/{ref}_{token}.pdf"

# Create your models here.
class Report(BaseModel):
    class StatusChoices(models.TextChoices):
        DRAFT = "draft", "Draft"
        IN_PROGRESS = "in_progress", "In Progress"
        SUSPENDED = "suspended", "Suspended"
        FINALIZED = "finalized", "Finalized"

    subject_content_type = models.ForeignKey(
        ContentType,
        on_delete=models.PROTECT,
        related_name="report_subject"
    )
    subject_object_id = models.PositiveIntegerField()
    subject = GenericForeignKey("subject_content_type", "subject_object_id")
    client_content_type = models.ForeignKey(
        ContentType,
        on_delete=models.PROTECT,
        related_name="report_clients"
    )
    client_object_id = models.PositiveIntegerField()
    client = GenericForeignKey( "client_content_type",  "client_object_id")
    analyst = models.ForeignKey(
        "users.User",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="analyst_reports"
    )
    report_narration = models.TextField(
        blank=True,
        null=True
    )
    contact_person = models.TextField(
        blank=True,
        null=True
    )
    username = models.CharField(
        max_length=50,
        blank=True,
        null=True
    )
    username_mobile = models.CharField(
        max_length=15,
        blank=True,
        null=True
    )
    status = models.CharField(
        max_length=20, 
        choices=StatusChoices.choices, 
        default=StatusChoices.IN_PROGRESS,
    )
    overall_risk_rating = models.CharField(
        max_length=50,
        blank=True,
        null=True
    )
    summary = models.TextField(
        blank=True, 
        null=True
    )
    suspension_reason = models.TextField(
        blank=True,
        null=True 
    )    
    snapshot = models.JSONField(
        _("Data ScreenShot"),
        default=dict,
        null= True,
        blank = True,
        encoder=DjangoJSONEncoder,
    )
    finalized_at = models.DateTimeField(
        null=True,
        blank=True
    )
    report_pdf = models.FileField(
        _("Report PDF"),
        upload_to=report_pdf_path,
        null=True,
        blank=True,
    )
    enquiry_reference = models.CharField(max_length=20, unique=True, editable=False)
    is_deleted = models.BooleanField(default=False)
    report_date = models.DateTimeField(blank=True, null=True)

    @property
    def is_stale(self):
        if self.status not in [self.StatusChoices.DRAFT, self.StatusChoices.IN_PROGRESS]:
            return False
        return timezone.now() - self.created_at > timedelta(days=3)

    @property
    def last_report(self):
        last = (
            Report.objects.filter(
                subject_content_type_id=self.subject_content_type_id,
                subject_object_id=self.subject_object_id,
                status=self.StatusChoices.FINALIZED,
            )
            .exclude(pk=self.pk)
            .order_by("-finalized_at")
            .first()
        )
        return last.created_at if last else None

    def save(self, *args, **kwargs):
        if not self.enquiry_reference:
            with transaction.atomic():
                now = timezone.now()
                prefix = now.strftime("%y%m")

                last = (
                    Report.objects.filter(enquiry_reference__startswith=prefix)
                    .select_for_update()
                    .order_by("-enquiry_reference")
                    .first()
                )
                seq = int(last.enquiry_reference[4:]) + 1 if last else 1
                self.enquiry_reference = f"{prefix}{seq:04d}"
                super().save(*args, **kwargs)
        else:
            super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        if self.report_pdf:
            self.report_pdf.delete(save=False)
        return super().delete(*args, **kwargs)
    
    class Meta:
        app_label = "reports"
        db_table = "reports"
        verbose_name = _("Enquiry Report")
        verbose_name_plural = _("Enquiry Reports")
        ordering = [
            OrderBy(Coalesce('report_date', 'created_at'), descending=True)
        ]
        constraints = [
            UniqueConstraint(
                fields= ["enquiry_reference"],
                name='unique_enquiry_reference'
            )   
        ]
    
    def __str__(self):
        return f"Report {self.enquiry_reference}"